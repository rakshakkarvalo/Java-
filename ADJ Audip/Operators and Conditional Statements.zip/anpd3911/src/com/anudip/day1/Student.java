package com.anudip.day1;

public class Student {

	public static void main(String[] args) {
		/*Comments are additional information which does not affect the execution of a program
		 * single line comment --> //
		 * Multi line comment --> /*   ---------------------   
		*/
		String name; //variable declaration
		name = "Vanisha";//variable initialization
		
		int age = 25;//variable declaration and initialization
		
		System.out.println("Student name : " + name);
		System.out.println("Student age : " + age);
		
		
	}

}
